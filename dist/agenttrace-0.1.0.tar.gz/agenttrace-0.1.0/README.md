# AgentTrace: Immutable Audit Logging & Edge PII Masking Gateway for Autonomous AI Agents

[![CI Matrix](https://github.com/Vinayakdata/AgentTrace/actions/workflows/ci.yml/badge.svg)](https://github.com/Vinayakdata/AgentTrace/actions/workflows/ci.yml)
[![PyPI version](https://badge.fury.io/py/agenttrace.svg)](https://badge.fury.io/py/agenttrace)
[![License: MIT](https://img.shields.io/badge/License-MIT-blue.svg)](LICENSE)
[![Python 3.10+](https://img.shields.io/badge/python-3.10+-blue.svg)](https://www.python.org/downloads/)

AgentTrace is a high-performance compliance, telemetry, and audit logging framework engineered specifically for autonomous multi-agent systems and LLM workflows. It combines non-blocking async telemetry SDKs, an inline deep-JSON PII redaction proxy gateway, state-aware semantic caching, client-side browser DOM tracking, and WORM (Write-Once-Read-Many) cryptographic audit proof receipts signed with Ed25519 digital signatures.

---

## Architecture Overview

```mermaid
flowchart TD
    subgraph Client Application / Agent Runtime
        SDK["Python SDK (AgentTraceTracker)"]
        Browser["JS SDK & Chrome Extension Sidecar"]
    end

    subgraph Edge / Reverse Proxy Layer
        Gateway["Gateway Proxy (gateway.py)"]
        PII["Deep-JSON PII Engine"]
        Cache["State-Aware Semantic Cache"]
    end

    subgraph Immutable Compliance Vault
        Ingest["Ingestion Service (ingest.py)"]
        WORM["WORM Cryptographic Vault (proof.json)"]
        Ed25519["Ed25519 Digital Signatures"]
    end

    SDK -->|Async Telemetry Queue| Ingest
    Browser -->|DOM Mutation Logs| Ingest
    SDK -->|LLM Requests| Gateway
    Gateway --> PII
    PII --> Cache
    Cache -->|Proxy Forward| UpstreamLLM["Upstream LLM API (OpenAI / Anthropic)"]
    Gateway -->|Correlation ID UUIDv7 Audit Trace| Ingest
    Ingest --> WORM
    WORM --> Ed25519
```

---

## Key Features

- **Non-Blocking Telemetry SDK**: Background worker thread pushes telemetry to non-blocking queues with sub-microsecond main-thread overhead.
- **Unified UUIDv7 Correlation**: Cross-links SDK trace sessions, Gateway LLM proxy calls, and browser DOM mutation sidecars using RFC 9562 UUIDv7.
- **Deep-JSON & Multi-Modal PII Redaction**: Recursively strips SSNs, Credit Cards, API Tokens (`sk-...`), and base64 vision image payloads out-of-band before persistent storage.
- **State-Aware Semantic Caching**: Identical prompts evaluated with matching state hashes trigger cache hits, serving cached responses instantly and saving 100% of LLM API costs.
- **WORM Audit Seal & Ed25519 Proof Receipts**: Cryptographically seals audit trails with deterministic HMAC-SHA256 digests and Ed25519 asymmetric signatures.
- **Fail-Open Architecture**: Proxy streams live inference payloads unmodified to upstream models even if telemetry ingest services crash.

---

## Installation

Install via PyPI:
```bash
pip install agenttrace
```

Install for local development:
```bash
git clone https://github.com/Vinayakdata/AgentTrace.git
cd AgentTrace
pip install -e .[dev]
```

---

## Quick Start

### 1. Python SDK Telemetry Session
```python
from agenttrace_sdk import AgentTraceTracker

tracker = AgentTraceTracker(ingestion_url="http://localhost:8000")

with tracker.trace_session(task_name="financial_audit_agent") as correlation_id:
    print(f"Session Correlation ID (UUIDv7): {correlation_id}")

    # Record agent event
    tracker.record_event(
        prompt_tokens=42,
        completion_tokens=108,
        completion_string="Compliance check completed successfully.",
        tool_calls=[{"name": "query_account_balance", "arguments": {"account_id": "1001"}}],
        agent_state={"memory_step": 1, "risk_score": 0.01}
    )

tracker.flush()
```

### 2. Gateway Proxy Request
```python
import httpx

client = httpx.Client()
response = client.post(
    "http://localhost:8011/v1/chat/completions",
    json={
        "model": "gpt-4o",
        "messages": [{"role": "user", "content": "Process transaction for SSN 123-45-6789"}]
    },
    headers={
        "X-AgentTrace-Correlation-ID": correlation_id,
        "X-AgentTrace-Enable-Caching": "true",
        "X-AgentTrace-State-Hash": "state_hash_v1"
    }
)

print(response.json())
```

---

## Verification & Proof Sealing Example

Seal an audit session and verify its cryptographic Ed25519 proof receipt:

```python
import httpx
from utils import verify_proof_receipt

# 1. Trigger session sealing endpoint
client = httpx.Client()
seal_res = client.post(
    "http://localhost:8000/ingest/seal",
    json={"correlation_id": correlation_id}
)
seal_data = seal_res.json()
print("WORM Proof Signature:", seal_data["hmac_signature"])

# 2. Verify proof receipt on disk
is_valid = verify_proof_receipt("proof.json", secret_key="agenttrace-production-worm-vault-key-2026")
print("Proof Receipt Valid:", is_valid)
```

---

## Benchmarking Methodology

AgentTrace includes a complete, executable benchmark suite ([`benchmarks/run_benchmarks.py`](file:///c:/Users/codew/agentrace/benchmarks/run_benchmarks.py)) designed for reproducible performance evaluation across:
1. **SDK Queue Overhead**: Main-thread microsecond latency per recorded event.
2. **Gateway Latency**: End-to-end response time percentiles (p50, p95, p99).
3. **Ed25519 Signing & Verification**: Operations per second and signature verification times.
4. **PII Engine Throughput**: Deep JSON redaction ops/sec and MB/sec throughput.
5. **State-Aware Cache**: Cache miss vs hit latency ratios and speedup multipliers.
6. **Concurrency & Soak**: Resource stability (CPU/Memory) under multi-threaded concurrency over time.

To execute the benchmark suite on your hardware:
```bash
python benchmarks/run_benchmarks.py
```

Generated metrics are exported without fabrication to `benchmark_results.json`, `benchmark_results.csv`, and `BENCHMARK_REPORT.md`.

---

## Roadmap

- **v0.1.0 MVP (Current)**: Async SDK, FastAPI Gateway, Ed25519 WORM receipts, Deep-JSON PII Engine, Manifest V3 Extension, State-Aware Cache.
- **v1.0.0 Production**: OpenTelemetry OTLP Exporter, Redis Distributed Caching Backend, Multi-Tenant API Auth.
- **v2.0.0 Distributed Scale**: eBPF Kernel Network Sidecar, Cloud Native WORM S3 Object Storage Locking.

---

## License

AgentTrace is licensed under the [MIT License](LICENSE).